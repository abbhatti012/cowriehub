<div class="footer">
    <div class="copyright">
        <p>Copyright: Cowrie Hub <br> Designed & Developed By: <a href="https://www.indigoadmarket.com" target="_blank">Indigo</a></p>
    </div>
</div>