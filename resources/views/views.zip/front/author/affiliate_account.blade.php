@extends('front.layout.index')
@section('content')
    <main id="content">
        <div class="container">
       
        </div>
    </main>
@endsection