@extends('front.layout.index')
@section('content')
    <main id="content">
        <div class="container">
            <div class="py-4 py-lg-5 py-xl-8">
                <h6 class="font-weight-medium font-size-7 font-size-xs-25 text-center">Frequently Asked Questions</h6>
            </div>
            <div class="col-lg-8 mx-auto">
                <div class="space-bottom-2 space-bottom-lg-3 faq-accordion">
                    <div class="pb-lg-1">
                        <div class="mb-8 pb-1">
                            <h6 class="font-weight-medium font-size-4 mb-5">Shopping</h6>
                            <!-- Basics Accordion -->
                            <div id="basicsAccordion">
                                <!-- Card -->
                                <div class="card rounded-0 border-0">
                                    <div class="card-collapse card-header p-0 bg-transparent border-bottom-0" id="basicsHeadingOne">
                                        <button type="button" class="collapse-link btn btn-block d-flex align-items-center justify-content-between card-btn py-3 px-0 px-md-4 border rounded-0 shadow-none"
                                                data-toggle="collapse"
                                                data-target="#basicsCollapseOne"
                                                aria-expanded="true"
                                                aria-controls="basicsCollapseOne">

                                            <span class="mx-md-1">Delivery charges for orders from the Online Shop?</span>

                                            <svg class="minus" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="15px" height="2px">
                                                <path fill-rule="evenodd" fill="rgb(22, 22, 25)" d="M0.000,-0.000 L15.000,-0.000 L15.000,2.000 L0.000,2.000 L0.000,-0.000 Z" />
                                            </svg>

                                            <svg class="plus" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="15px" height="15px">
                                                <path fill-rule="evenodd" fill="rgb(22, 22, 25)" d="M15.000,8.000 L9.000,8.000 L9.000,15.000 L7.000,15.000 L7.000,8.000 L0.000,8.000 L0.000,6.000 L7.000,6.000 L7.000,-0.000 L9.000,-0.000 L9.000,6.000 L15.000,6.000 L15.000,8.000 Z" />
                                            </svg>
                                        </button>
                                    </div>
                                    <div id="basicsCollapseOne" class="collapse show"
                                         aria-labelledby="basicsHeadingOne"
                                         data-parent="#basicsAccordion">
                                        <div class="card-body p-3 p-md-4">
                                            <div class="mx-md-1">
                                                <p class="mb-4 pb-1 font-size-2">A placerat ac vestibulum integer vehicula suspendisse nostra aptent fermentum tempor a magna erat ligula parturient curae sem conubia vestibulum ac inceptos sodales condimentum cursus nunc mi consectetur condimentum.</p>
                                                <span class="font-size-2">Tristique parturient nulla ullamcorper at ullamcorper non orci iaculis neque augue.</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Card -->

                                <!-- Card -->
                                <div class="card rounded-0 border-0 ">
                                    <div class="card-header card-collapse p-0 bg-transparent border-bottom-0" id="basicsHeadingTwo">
                                      <h5 class="mb-0">
                                        <button type="button" class="collapse-link btn btn-block d-flex align-items-center justify-content-between card-btn py-3 px-0 px-md-4 border rounded-0 shadow-none mt-minus-1"
                                                data-toggle="collapse"
                                                data-target="#basicsCollapseTwo"
                                                aria-expanded="false"
                                                aria-controls="basicsCollapseTwo">
                                          <span class="mx-md-1">How long will delivery take?</span>

                                            <svg class="minus" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="15px" height="2px">
                                                <path fill-rule="evenodd" fill="rgb(22, 22, 25)" d="M0.000,-0.000 L15.000,-0.000 L15.000,2.000 L0.000,2.000 L0.000,-0.000 Z" />
                                            </svg>

                                            <svg class="plus" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="15px" height="15px">
                                                <path fill-rule="evenodd" fill="rgb(22, 22, 25)" d="M15.000,8.000 L9.000,8.000 L9.000,15.000 L7.000,15.000 L7.000,8.000 L0.000,8.000 L0.000,6.000 L7.000,6.000 L7.000,-0.000 L9.000,-0.000 L9.000,6.000 L15.000,6.000 L15.000,8.000 Z" />
                                            </svg>
                                        </button>
                                      </h5>
                                    </div>
                                    <div id="basicsCollapseTwo" class="collapse" aria-labelledby="basicsHeadingTwo" data-parent="#basicsAccordion">
                                        <div class="card-body p-3 p-md-4">
                                            <div class=" m-1">
                                                <p class="mb-4 pb-1 font-size-2">A placerat ac vestibulum integer vehicula suspendisse nostra aptent fermentum tempor a magna erat ligula parturient curae sem conubia vestibulum ac inceptos sodales condimentum cursus nunc mi consectetur condimentum.</p>
                                                <span class="font-size-2">Tristique parturient nulla ullamcorper at ullamcorper non orci iaculis neque augue.</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Card -->

                                <!-- Card -->
                                <div class="card rounded-0 border-0">
                                    <div class="card-header card-collapse p-0 bg-transparent border-bottom-0" id="basicsHeadingThree">

                                        <button type="button" class="collapse-link btn btn-block d-flex align-items-center justify-content-between card-btn py-3 px-0 px-md-4 border rounded-0 shadow-none mt-minus-1"
                                                data-toggle="collapse"
                                                data-target="#basicsCollapseThree"
                                                aria-expanded="false"
                                                aria-controls="basicsCollapseThree">
                                            <span class="mx-md-1">Do I receive an invoice for my order?</span>

                                            <svg class="minus" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="15px" height="2px">
                                                <path fill-rule="evenodd" fill="rgb(22, 22, 25)" d="M0.000,-0.000 L15.000,-0.000 L15.000,2.000 L0.000,2.000 L0.000,-0.000 Z" />
                                            </svg>

                                            <svg class="plus" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="15px" height="15px">
                                                <path fill-rule="evenodd" fill="rgb(22, 22, 25)" d="M15.000,8.000 L9.000,8.000 L9.000,15.000 L7.000,15.000 L7.000,8.000 L0.000,8.000 L0.000,6.000 L7.000,6.000 L7.000,-0.000 L9.000,-0.000 L9.000,6.000 L15.000,6.000 L15.000,8.000 Z" />
                                            </svg>
                                        </button>
                                    </div>
                                    <div id="basicsCollapseThree" class="collapse" aria-labelledby="basicsHeadingThree" data-parent="#basicsAccordion">
                                        <div class="card-body p-3 p-md-4">
                                            <div class="mx-md-1">
                                                <p class="mb-4 pb-1 font-size-2">A placerat ac vestibulum integer vehicula suspendisse nostra aptent fermentum tempor a magna erat ligula parturient curae sem conubia vestibulum ac inceptos sodales condimentum cursus nunc mi consectetur condimentum.</p>
                                                <span class="font-size-2">Tristique parturient nulla ullamcorper at ullamcorper non orci iaculis neque augue.</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Card -->

                                <!-- Card -->
                                <div class="card rounded-0 border-0">
                                    <div class="card-header card-collapse p-0 bg-transparent border-bottom-0" id="basicsHeadingFour">

                                        <button type="button" class="collapse-link btn btn-block d-flex align-items-center justify-content-between card-btn py-3 px-0 px-md-4 border rounded-0 shadow-none mt-minus-1"
                                                data-toggle="collapse"
                                                data-target="#basicsCollapseFour"
                                                aria-expanded="false"
                                                aria-controls="basicsCollapseFour">
                                            <span class="mx-1">Tellus ridicdiam eleifend id ullamcorper?</span>

                                            <svg class="minus" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="15px" height="2px">
                                                <path fill-rule="evenodd" fill="rgb(22, 22, 25)" d="M0.000,-0.000 L15.000,-0.000 L15.000,2.000 L0.000,2.000 L0.000,-0.000 Z" />
                                            </svg>

                                            <svg class="plus" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="15px" height="15px">
                                                <path fill-rule="evenodd" fill="rgb(22, 22, 25)" d="M15.000,8.000 L9.000,8.000 L9.000,15.000 L7.000,15.000 L7.000,8.000 L0.000,8.000 L0.000,6.000 L7.000,6.000 L7.000,-0.000 L9.000,-0.000 L9.000,6.000 L15.000,6.000 L15.000,8.000 Z" />
                                            </svg>
                                        </button>
                                    </div>
                                    <div id="basicsCollapseFour" class="collapse" aria-labelledby="basicsHeadingFour" data-parent="#basicsAccordion">
                                        <div class="card-body p-3 p-md-4">
                                            <div class="mx-md-1">
                                                <p class="mb-4 pb-1 font-size-2">A placerat ac vestibulum integer vehicula suspendisse nostra aptent fermentum tempor a magna erat ligula parturient curae sem conubia vestibulum ac inceptos sodales condimentum cursus nunc mi consectetur condimentum.</p>
                                                <span class="font-size-2">Tristique parturient nulla ullamcorper at ullamcorper non orci iaculis neque augue.</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Card -->
                            </div>
                            <!-- End Basics Accordion -->
                        </div>
                        <div>
                            <h6 class="font-weight-medium font-size-4 mb-5">Payment</h6>
                            <!-- Basics Accordion -->
                            <div id="basicsAccordion1">
                                <!-- Card -->
                                <div class="card rounded-0 border-0">
                                    <div class="card-collapse card-header p-0 bg-transparent border-bottom-0" id="basicsHeadingFive">
                                        <button type="button" class="collapse-link btn btn-block d-flex align-items-center justify-content-between card-btn py-3 px-0 px-md-4 border rounded-0 shadow-none"
                                                data-toggle="collapse"
                                                data-target="#basicsCollapseFive"
                                                aria-expanded="true"
                                                aria-controls="basicsCollapseFive">

                                            <span class="mx-md-1">When the order payment is taken of my bank account?</span>

                                            <svg class="minus" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="15px" height="2px">
                                                <path fill-rule="evenodd" fill="rgb(22, 22, 25)" d="M0.000,-0.000 L15.000,-0.000 L15.000,2.000 L0.000,2.000 L0.000,-0.000 Z" />
                                            </svg>

                                            <svg class="plus" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="15px" height="15px">
                                                <path fill-rule="evenodd" fill="rgb(22, 22, 25)" d="M15.000,8.000 L9.000,8.000 L9.000,15.000 L7.000,15.000 L7.000,8.000 L0.000,8.000 L0.000,6.000 L7.000,6.000 L7.000,-0.000 L9.000,-0.000 L9.000,6.000 L15.000,6.000 L15.000,8.000 Z" />
                                            </svg>
                                        </button>
                                    </div>
                                    <div id="basicsCollapseFive" class="collapse show"
                                         aria-labelledby="basicsHeadingFive"
                                         data-parent="#basicsAccordion1">
                                        <div class="card-body p-3 p-md-4">
                                            <div class=" mx-md-1">
                                                <p class="mb-4 pb-1 font-size-2">A placerat ac vestibulum integer vehicula suspendisse nostra aptent fermentum tempor a magna erat ligula parturient curae sem conubia vestibulum ac inceptos sodales condimentum cursus nunc mi consectetur condimentum.</p>
                                                <span class="font-size-2">Tristique parturient nulla ullamcorper at ullamcorper non orci iaculis neque augue.</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Card -->

                                <!-- Card -->
                                <div class="card rounded-0 border-0 ">
                                    <div class="card-header card-collapse p-0 bg-transparent border-bottom-0" id="basicsHeadingSix">
                                      <h5 class="mb-0">
                                        <button type="button" class="collapse-link btn btn-block d-flex align-items-center justify-content-between card-btn py-3 px-0 px-md-4 border rounded-0 shadow-none mt-minus-1"
                                                data-toggle="collapse"
                                                data-target="#basicsCollapseSix"
                                                aria-expanded="false"
                                                aria-controls="basicsCollapseSix">
                                          <span class="mx-1">What is wishlist?</span>

                                            <svg class="minus" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="15px" height="2px">
                                                <path fill-rule="evenodd" fill="rgb(22, 22, 25)" d="M0.000,-0.000 L15.000,-0.000 L15.000,2.000 L0.000,2.000 L0.000,-0.000 Z" />
                                            </svg>

                                            <svg class="plus" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="15px" height="15px">
                                                <path fill-rule="evenodd" fill="rgb(22, 22, 25)" d="M15.000,8.000 L9.000,8.000 L9.000,15.000 L7.000,15.000 L7.000,8.000 L0.000,8.000 L0.000,6.000 L7.000,6.000 L7.000,-0.000 L9.000,-0.000 L9.000,6.000 L15.000,6.000 L15.000,8.000 Z" />
                                            </svg>
                                        </button>
                                      </h5>
                                    </div>
                                    <div id="basicsCollapseSix" class="collapse" aria-labelledby="basicsHeadingSix" data-parent="#basicsAccordion1">
                                        <div class="card-body p-3 p-md-4">
                                            <div class="mx-md-1">
                                                <p class="mb-4 pb-1 font-size-2">A placerat ac vestibulum integer vehicula suspendisse nostra aptent fermentum tempor a magna erat ligula parturient curae sem conubia vestibulum ac inceptos sodales condimentum cursus nunc mi consectetur condimentum.</p>
                                                <span class="font-size-2">Tristique parturient nulla ullamcorper at ullamcorper non orci iaculis neque augue.</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Card -->

                                <!-- Card -->
                                <div class="card rounded-0 border-0">
                                    <div class="card-header card-collapse p-0 bg-transparent border-bottom-0" id="basicsHeadingSeven">

                                        <button type="button" class="collapse-link btn btn-block d-flex align-items-center justify-content-between card-btn py-3 px-0 px-md-4 border rounded-0 shadow-none mt-minus-1"
                                                data-toggle="collapse"
                                                data-target="#basicsCollapseSeven"
                                                aria-expanded="false"
                                                aria-controls="basicsCollapseSeven">
                                            <span class="mx-md-1">What should I do if I receive a damaged or wrong product?</span>

                                            <svg class="minus" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="15px" height="2px">
                                                <path fill-rule="evenodd" fill="rgb(22, 22, 25)" d="M0.000,-0.000 L15.000,-0.000 L15.000,2.000 L0.000,2.000 L0.000,-0.000 Z" />
                                            </svg>

                                            <svg class="plus" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="15px" height="15px">
                                                <path fill-rule="evenodd" fill="rgb(22, 22, 25)" d="M15.000,8.000 L9.000,8.000 L9.000,15.000 L7.000,15.000 L7.000,8.000 L0.000,8.000 L0.000,6.000 L7.000,6.000 L7.000,-0.000 L9.000,-0.000 L9.000,6.000 L15.000,6.000 L15.000,8.000 Z" />
                                            </svg>
                                        </button>
                                    </div>
                                    <div id="basicsCollapseSeven" class="collapse" aria-labelledby="basicsHeadingSeven" data-parent="#basicsAccordion1">
                                        <div class="card-body p-3 p-md-4">
                                            <div class="mx-md-1">
                                                <p class="mb-4 pb-1 font-size-2">A placerat ac vestibulum integer vehicula suspendisse nostra aptent fermentum tempor a magna erat ligula parturient curae sem conubia vestibulum ac inceptos sodales condimentum cursus nunc mi consectetur condimentum.</p>
                                                <span class="font-size-2">Tristique parturient nulla ullamcorper at ullamcorper non orci iaculis neque augue.</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Card -->
                                <!-- Card -->
                                <div class="card rounded-0 border-0">
                                    <div class="card-header card-collapse p-0 bg-transparent border-bottom-0" id="basicsHeadingEight">

                                        <button type="button" class="collapse-link btn btn-block d-flex align-items-center justify-content-between card-btn py-3 px-0 px-md-4 border rounded-0 shadow-none mt-minus-1"
                                                data-toggle="collapse"
                                                data-target="#basicsCollapseEight"
                                                aria-expanded="false"
                                                aria-controls="basicsCollapseEight">
                                            <span class="mx-md-1">Can I change or cancel my order?</span>

                                            <svg class="minus" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="15px" height="2px">
                                                <path fill-rule="evenodd" fill="rgb(22, 22, 25)" d="M0.000,-0.000 L15.000,-0.000 L15.000,2.000 L0.000,2.000 L0.000,-0.000 Z" />
                                            </svg>

                                            <svg class="plus" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="15px" height="15px">
                                                <path fill-rule="evenodd" fill="rgb(22, 22, 25)" d="M15.000,8.000 L9.000,8.000 L9.000,15.000 L7.000,15.000 L7.000,8.000 L0.000,8.000 L0.000,6.000 L7.000,6.000 L7.000,-0.000 L9.000,-0.000 L9.000,6.000 L15.000,6.000 L15.000,8.000 Z" />
                                            </svg>
                                        </button>
                                    </div>
                                    <div id="basicsCollapseEight" class="collapse" aria-labelledby="basicsHeadingEight" data-parent="#basicsAccordion1">
                                        <div class="card-body p-3 p-md-4">
                                            <div class="mx-md-1">
                                                <p class="mb-4 pb-1 font-size-2">A placerat ac vestibulum integer vehicula suspendisse nostra aptent fermentum tempor a magna erat ligula parturient curae sem conubia vestibulum ac inceptos sodales condimentum cursus nunc mi consectetur condimentum.</p>
                                                <span class="font-size-2">Tristique parturient nulla ullamcorper at ullamcorper non orci iaculis neque augue.</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Card -->
                                <!-- Card -->
                                <div class="card rounded-0 border-0">
                                    <div class="card-header card-collapse p-0 bg-transparent border-bottom-0" id="basicsHeadingNine">

                                        <button type="button" class="collapse-link btn btn-block d-flex align-items-center justify-content-between card-btn py-3 px-0 px-md-4 border rounded-0 shadow-none mt-minus-1"
                                                data-toggle="collapse"
                                                data-target="#basicsCollapseNine"
                                                aria-expanded="false"
                                                aria-controls="basicsCollapseNine">
                                            <span class="mx-md-1">What is "package tracking" in my orders?</span>

                                            <svg class="minus" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="15px" height="2px">
                                                <path fill-rule="evenodd" fill="rgb(22, 22, 25)" d="M0.000,-0.000 L15.000,-0.000 L15.000,2.000 L0.000,2.000 L0.000,-0.000 Z" />
                                            </svg>

                                            <svg class="plus" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="15px" height="15px">
                                                <path fill-rule="evenodd" fill="rgb(22, 22, 25)" d="M15.000,8.000 L9.000,8.000 L9.000,15.000 L7.000,15.000 L7.000,8.000 L0.000,8.000 L0.000,6.000 L7.000,6.000 L7.000,-0.000 L9.000,-0.000 L9.000,6.000 L15.000,6.000 L15.000,8.000 Z" />
                                            </svg>
                                        </button>
                                    </div>
                                    <div id="basicsCollapseNine" class="collapse" aria-labelledby="basicsHeadingNine" data-parent="#basicsAccordion1">
                                        <div class="card-body p-3 p-md-4">
                                            <div class="mx-md-1">
                                                <p class="mb-4 pb-1 font-size-2">A placerat ac vestibulum integer vehicula suspendisse nostra aptent fermentum tempor a magna erat ligula parturient curae sem conubia vestibulum ac inceptos sodales condimentum cursus nunc mi consectetur condimentum.</p>
                                                <span class="font-size-2">Tristique parturient nulla ullamcorper at ullamcorper non orci iaculis neque augue.</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Card -->
                            </div>
                            <!-- End Basics Accordion -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
@endsection