# Date Range Picker

A Pen created on CodePen.io. Original URL: [https://codepen.io/meeraan/pen/NgeXYX](https://codepen.io/meeraan/pen/NgeXYX).

iQuery Date time Range picker to select  Date & time range